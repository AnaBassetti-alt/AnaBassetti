/* Traduções e configuração de endereços confirmados. */
const translations = {
  "nav_home": [
    "Início",
    "Home"
  ],
  "nav_about": [
    "Sobre",
    "About"
  ],
  "nav_education": [
    "Formação",
    "Education"
  ],
  "nav_skills": [
    "Tecnologias",
    "Skills"
  ],
  "nav_projects": [
    "Projetos",
    "Projects"
  ],
  "nav_contact": [
    "Contato",
    "Contact"
  ],
  "area0": [
    "Front-end",
    "Front-end"
  ],
  "aread0": [
    "Interfaces web, estrutura visual e interação com o usuário.",
    "Web interfaces, visual structure and user interaction."
  ],
  "area1": [
    "Back-end",
    "Back-end"
  ],
  "aread1": [
    "Lógica de aplicações e organização de serviços.",
    "Application logic and service organization."
  ],
  "area2": [
    "Mobile",
    "Mobile"
  ],
  "aread2": [
    "Concepção de aplicações para dispositivos móveis.",
    "Design and development of mobile applications."
  ],
  "area3": [
    "Banco de dados",
    "Databases"
  ],
  "aread3": [
    "Modelagem, armazenamento e consulta de informações.",
    "Data modeling, storage and queries."
  ],
  "area4": [
    "Versionamento",
    "Version control"
  ],
  "aread4": [
    "Controle de alterações e colaboração em código.",
    "Change tracking and code collaboration."
  ],
  "area5": [
    "Inteligência artificial",
    "Artificial intelligence"
  ],
  "aread5": [
    "Exploração de conceitos e aplicações de IA.",
    "Exploration of AI concepts and applications."
  ],
  "area6": [
    "Projetos multidisciplinares",
    "Multidisciplinary projects"
  ],
  "aread6": [
    "Integração de conhecimentos em soluções práticas.",
    "Integration of knowledge into practical solutions."
  ],
  "pname0": [
    "ELORA",
    "ELORA"
  ],
  "pdesc0": [
    "Projeto autoral de jogo narrativo com atmosfera psicológica, exploração e elementos interativos. Envolve construção de universo ficcional, desenvolvimento de personagens, narrativa ambiental e concepção de experiências para o jogador.",
    "An original narrative game project with a psychological atmosphere, exploration and interactive elements. It involves fictional worldbuilding, character development, environmental storytelling and designing player experiences."
  ],
  "pcat0": [
    "Jogo narrativo interativo",
    "Interactive Narrative Game"
  ],
  "concept0": [
    "Arte conceitual · não representa uma captura do projeto",
    "Concept artwork · not a project screenshot"
  ],
  "details0": [
    "Informações do projeto",
    "Project information"
  ],
  "pending0": [
    "Tecnologias específicas e endereço do projeto ainda não informados.",
    "Project-specific technologies and URL have not been provided yet."
  ],
  "pname1": [
    "Aplicações Financeiras",
    "Financial Applications"
  ],
  "pdesc1": [
    "Desenvolvimento de aplicações voltadas à organização financeira, gerenciamento de informações, controle de movimentações e visualização de dados.",
    "Development of applications focused on financial organization, information management, transaction tracking and data visualization."
  ],
  "pcat1": [
    "Aplicações de gestão financeira",
    "Financial Management Applications"
  ],
  "concept1": [
    "Arte conceitual · não representa uma captura do projeto",
    "Concept artwork · not a project screenshot"
  ],
  "details1": [
    "Informações do projeto",
    "Project information"
  ],
  "pending1": [
    "Tecnologias específicas e endereço do projeto ainda não informados.",
    "Project-specific technologies and URL have not been provided yet."
  ],
  "pname2": [
    "GENESIS",
    "GENESIS"
  ],
  "pdesc2": [
    "Projeto digital de exploração e educação sobre o ambiente marinho, com uma experiência interativa de exploração subaquática e representação de profundidade, pressão e fauna marinha.",
    "A digital exploration and education project about the marine environment, featuring interactive underwater exploration and representations of depth, pressure and marine fauna."
  ],
  "pcat2": [
    "Projeto de evolução oceânica",
    "The Ocean Evolution Project"
  ],
  "concept2": [
    "Arte conceitual · não representa uma captura do projeto",
    "Concept artwork · not a project screenshot"
  ],
  "details2": [
    "Informações do projeto",
    "Project information"
  ],
  "pending2": [
    "Tecnologias específicas e endereço do projeto ainda não informados.",
    "Project-specific technologies and URL have not been provided yet."
  ],
  "pname3": [
    "Ocarina Hub",
    "Ocarina Hub"
  ],
  "pdesc3": [
    "Desenvolvimento de uma plataforma temática dedicada a The Legend of Zelda: Ocarina of Time, com organização de conteúdo e experiência de navegação.",
    "Development of a themed platform dedicated to The Legend of Zelda: Ocarina of Time, with content organization and a navigation experience."
  ],
  "pcat3": [
    "Plataforma de informações sobre jogos",
    "Gaming Information Platform"
  ],
  "concept3": [
    "Arte conceitual · não representa uma captura do projeto",
    "Concept artwork · not a project screenshot"
  ],
  "details3": [
    "Informações do projeto",
    "Project information"
  ],
  "pending3": [
    "Tecnologias específicas e endereço do projeto ainda não informados.",
    "Project-specific technologies and URL have not been provided yet."
  ],
  "skip": [
    "Ir para o conteúdo",
    "Skip to content"
  ],
  "student": [
    "ESTUDANTE DE DESENVOLVIMENTO DE SISTEMAS",
    "SOFTWARE DEVELOPMENT STUDENT"
  ],
  "portfolio": [
    "PORTFÓLIO PROFISSIONAL / DESENVOLVIMENTO DE SOFTWARE",
    "PROFESSIONAL PORTFOLIO / SOFTWARE DEVELOPMENT"
  ],
  "hero": [
    "Transformando ideias em soluções funcionais.",
    "Transforming ideas into functional solutions."
  ],
  "intro": [
    "Sou estudante de Desenvolvimento de Sistemas, com interesse em desenvolvimento de software, jogos e aplicações web e mobile. Tenho perfil multidisciplinar, proativo, criativo e comunicativo, com iniciativa para aprender e transformar ideias em soluções digitais funcionais, acessíveis e relevantes.",
    "I am a Systems Development student interested in software development, games, and web and mobile applications. I bring a multidisciplinary, proactive, creative and communicative approach, with the initiative to learn and turn ideas into functional, accessible and meaningful digital solutions."
  ],
  "explore": [
    "Explorar meus projetos",
    "Explore my projects"
  ],
  "aboutbtn": [
    "Sobre mim",
    "About me"
  ],
  "art": [
    "IDEIA → ESTRUTURA → SOLUÇÃO",
    "IDEA → STRUCTURE → SOLUTION"
  ],
  "scroll": [
    "Explore o portfólio",
    "Explore the portfolio"
  ],
  "aboutlabel": [
    "PERFIL",
    "PROFILE"
  ],
  "abouttitle": [
    "Além do código.",
    "Beyond the code."
  ],
  "about1": [
    "Minha formação em Desenvolvimento de Sistemas me proporcionou contato com diferentes etapas da criação de soluções tecnológicas, desde a estruturação de interfaces e a lógica de programação até bancos de dados e aplicações web e mobile.",
    "My Systems Development education introduced me to different stages of creating technology solutions, from interface design and programming logic to databases and web and mobile applications."
  ],
  "about2": [
    "Tenho facilidade para explorar novas ferramentas, desenvolver ideias e participar ativamente de processos criativos e colaborativos.",
    "I enjoy exploring new tools, developing ideas and actively participating in creative and collaborative processes."
  ],
  "about3": [
    "Acredito que desenvolver tecnologia envolve mais do que escrever código: exige pensamento analítico, organização, criatividade e capacidade de compreender problemas para construir soluções.",
    "I believe technology development involves more than writing code: it requires analytical thinking, organization, creativity and the ability to understand problems in order to build solutions."
  ],
  "q0": [
    "Proatividade",
    "Proactivity"
  ],
  "qd0": [
    "Iniciativa para buscar conhecimento, explorar ferramentas, identificar necessidades e avançar na construção de soluções.",
    "Initiative to seek knowledge, explore tools, identify needs and advance solutions."
  ],
  "q1": [
    "Comunicação",
    "Communication"
  ],
  "qd1": [
    "Facilidade para expressar ideias, compartilhar conhecimentos e participar de atividades colaborativas.",
    "Ability to express ideas, share knowledge and participate in collaborative activities."
  ],
  "q2": [
    "Criatividade",
    "Creativity"
  ],
  "qd2": [
    "Capacidade de desenvolver ideias, explorar diferentes abordagens e contribuir para a criação de produtos digitais.",
    "Ability to develop ideas, explore different approaches and contribute to digital products."
  ],
  "edlabel": [
    "FORMAÇÃO",
    "EDUCATION"
  ],
  "edtitle": [
    "Conhecimento em construção.",
    "Knowledge in the making."
  ],
  "course": [
    "Técnico em Desenvolvimento de Sistemas",
    "Technical program in Systems Development"
  ],
  "mode": [
    "Ensino Médio integrado à formação técnica.",
    "High school integrated with technical education."
  ],
  "skilllabel": [
    "REPERTÓRIO TÉCNICO",
    "TECHNICAL TOOLKIT"
  ],
  "skilltitle": [
    "Tecnologias e ferramentas.",
    "Technologies and tools."
  ],
  "level": [
    "Nível declarado: intermediário nas tecnologias principais. Django: nível não especificado.",
    "Self-reported level: intermediate in the main technologies. Django: proficiency level not specified."
  ],
  "lang": [
    "Linguagens",
    "Languages"
  ],
  "stack": [
    "Desenvolvimento web",
    "Web development"
  ],
  "tools": [
    "Ferramentas",
    "Tools"
  ],
  "work": [
    "TRABALHOS SELECIONADOS",
    "SELECTED WORK"
  ],
  "projecttitle": [
    "Projetos selecionados.",
    "Selected projects."
  ],
  "projectintro": [
    "Exploração de ideias em diferentes contextos: narrativa, finanças, educação e jogos.",
    "Exploring ideas across different contexts: narrative, finance, education and gaming."
  ],
  "explabel": [
    "EXPERIÊNCIA COMPLEMENTAR",
    "COMPLEMENTARY EXPERIENCE"
  ],
  "exptitle": [
    "Desenvolvimento profissional.",
    "Professional development."
  ],
  "visit": [
    "Visita técnica",
    "Technical visit"
  ],
  "visitdesc": [
    "Experiência de aproximação com o ambiente profissional de tecnologia, complementando a formação técnica.",
    "An opportunity to get closer to the professional technology environment, complementing technical education."
  ],
  "contactlabel": [
    "CONTATO",
    "CONTACT"
  ],
  "connect": [
    "Vamos conversar.",
    "Let’s connect."
  ],
  "contactintro": [
    "Aberta a conexões profissionais, troca de ideias e oportunidades de aprendizado.",
    "Open to professional connections, exchanging ideas and learning opportunities."
  ],
  "contact_email": [
    "E-mail profissional",
    "Professional email"
  ],
  "status_email": [
    "Endereço a informar",
    "Address to be provided"
  ],
  "contact_github": [
    "GitHub",
    "GitHub"
  ],
  "status_github": [
    "Endereço a informar",
    "Address to be provided"
  ],
  "contact_linkedin": [
    "LinkedIn",
    "LinkedIn"
  ],
  "status_linkedin": [
    "Endereço a informar",
    "Address to be provided"
  ],
  "footer": [
    "Ana Clara Bassetti · Portfólio profissional",
    "Ana Clara Bassetti · Professional portfolio"
  ],
  "top": [
    "Voltar ao topo",
    "Back to top"
  ],
  "about4": [
    "Tenho interesse no desenvolvimento de experiências digitais acessíveis e inclusivas, considerando a diversidade de usuários e suas formas de interação. Busco explorar design inclusivo, usabilidade, navegação intuitiva, organização semântica e experiência do usuário para construir interfaces compreensíveis e funcionais.",
    "I am interested in developing accessible and inclusive digital experiences that consider diverse users and ways of interacting. I aim to explore inclusive design, usability, intuitive navigation, semantic structure and user experience to build understandable and functional interfaces."
  ],
  "about5": [
    "Tenho interesse no desenvolvimento de jogos e experiências interativas, explorando tecnologia, narrativa, design, personagens, lógica de interação e ambientes digitais. O projeto ELORA reflete esse interesse pela criação de experiências que envolvam o usuário.",
    "I am interested in game development and interactive experiences, exploring technology, storytelling, design, characters, interaction logic and digital environments. ELORA reflects this interest in creating engaging user experiences."
  ],
  "q3": [
    "Adaptabilidade",
    "Adaptability"
  ],
  "qd3": [
    "Interesse em aprender novas tecnologias e transitar entre diferentes áreas do desenvolvimento de sistemas.",
    "Interest in learning new technologies and moving across different areas of systems development."
  ],
  "q4": [
    "Pensamento analítico",
    "Analytical thinking"
  ],
  "qd4": [
    "Capacidade de compreender problemas, organizar informações e estruturar caminhos para desenvolver soluções.",
    "Ability to understand problems, organize information and structure approaches to developing solutions."
  ],
  "q5": [
    "Visão multidisciplinar",
    "Multidisciplinary perspective"
  ],
  "qd5": [
    "Interesse em conectar programação, design, acessibilidade, experiência do usuário e desenvolvimento de jogos.",
    "Interest in connecting programming, design, accessibility, user experience and game development."
  ],
  "mobile": [
    "Desenvolvimento mobile",
    "Mobile development"
  ],
  "database": [
    "Banco de dados",
    "Databases"
  ],
  "contact_phone": [
    "Telefone",
    "Phone"
  ],
  "contact_location": [
    "Localização",
    "Location"
  ],
  "location": [
    "São Paulo — SP, Brasil",
    "São Paulo — SP, Brazil"
  ]
};
const contacts = { email: '', github: '', linkedin: '' };
const projectLinks = ['', '', '', '']; // URLs confirmadas, na ordem dos projetos.
const menu = document.querySelector('.menu');
const nav = document.querySelector('#navigation');
let language = 'pt';
function closeMenu() { menu.setAttribute('aria-expanded','false'); nav.classList.remove('open'); menu.setAttribute('aria-label', language === 'pt' ? 'Abrir menu' : 'Open menu'); }
function renderLanguage(lang) {
 language = lang; document.documentElement.lang = lang === 'pt' ? 'pt-BR' : 'en';
 document.querySelectorAll('[data-i18n]').forEach(el => { el.textContent = translations[el.dataset.i18n][lang === 'pt' ? 0 : 1]; });
 document.querySelectorAll('[data-lang]').forEach(el => el.setAttribute('aria-pressed', String(el.dataset.lang === lang)));
 nav.setAttribute('aria-label', lang === 'pt' ? 'Navegação principal' : 'Main navigation');
 menu.setAttribute('aria-label', menu.getAttribute('aria-expanded') === 'true' ? (lang === 'pt' ? 'Fechar menu' : 'Close menu') : (lang === 'pt' ? 'Abrir menu' : 'Open menu'));
 document.querySelectorAll('.project-link').forEach(el => el.textContent = lang === 'pt' ? 'Ver projeto ↗' : 'View project ↗');
 try { localStorage.setItem('bassetti-language', lang); } catch (_) {}
}
function setupLinks() {
 Object.entries(contacts).forEach(([key,value]) => { if (!value) return; const row = document.querySelector(`[data-contact="${key}"]`); if (!row) return; const a = document.createElement('a'); a.href = key === 'email' ? 'mailto:'+value : value; a.textContent = value; row.querySelector('.contact-status').replaceWith(a); });
 document.querySelectorAll('.project').forEach((card,i) => { if (!projectLinks[i]) return; const a = document.createElement('a'); a.href = projectLinks[i]; a.className = 'button project-link'; card.querySelector('.project-copy').append(a); });
}
function setupNavigation() {
 menu.addEventListener('click', () => { if (menu.getAttribute('aria-expanded') === 'true') closeMenu(); else { nav.classList.add('open'); menu.setAttribute('aria-expanded','true'); menu.setAttribute('aria-label', language === 'pt' ? 'Fechar menu' : 'Close menu'); } });
 nav.querySelectorAll('a').forEach(a => a.addEventListener('click', closeMenu));
 document.addEventListener('keydown', e => { if(e.key === 'Escape' && nav.classList.contains('open')) { closeMenu(); menu.focus(); } });
 window.matchMedia('(min-width: 901px)').addEventListener('change', closeMenu);
 const sections = [...document.querySelectorAll('main section[id]')];
 let scheduled = false;
 function updateActive(){ scheduled = false; const y = window.scrollY + 120; let current = sections[0].id; sections.forEach(s => {if(s.offsetTop <= y) current=s.id;}); if(current === 'experience') current='projects'; if(window.scrollY + innerHeight >= document.documentElement.scrollHeight - 4) current='contact'; nav.querySelectorAll('a').forEach(a => { const active=a.hash === '#'+current; if(active) a.setAttribute('aria-current','location'); else a.removeAttribute('aria-current'); }); }
 window.addEventListener('scroll', () => {if(!scheduled){scheduled=true;requestAnimationFrame(updateActive);}}, {passive:true}); window.addEventListener('resize',updateActive); updateActive();
}
function setupMotion(){ if(!('IntersectionObserver' in window) || matchMedia('(prefers-reduced-motion: reduce)').matches) return; const observer=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('visible');observer.unobserve(e.target);}}),{threshold:0.08}); document.querySelectorAll('.reveal').forEach(el=>{el.classList.add('motion');observer.observe(el);}); }
setupLinks(); setupNavigation(); setupMotion();
document.querySelectorAll('[data-lang]').forEach(b=>b.addEventListener('click',()=>renderLanguage(b.dataset.lang)));
let saved; try { saved=localStorage.getItem('bassetti-language'); } catch (_) {} renderLanguage(saved === 'en' ? 'en' : 'pt');
